#!/usr/bin/env python3
"""
研究质量检查脚本
检查研究报告的完整性和质量指标
"""

import sys
import re
from pathlib import Path

def check_report(file_path):
    """检查研究报告质量"""
    if not Path(file_path).exists():
        print(f"[ERROR] 文件不存在: {file_path}")
        return False
    
    content = Path(file_path).read_text()
    
    # 检查章节完整性
    required_sections = [
        "研究背景",
        "市场分析",
        "商业场景",
        "数据需求",
        "商业模式",
        "风险评估",
        "优先级推荐",
        "下一步"
    ]
    
    print("=" * 50)
    print("研究质量检查")
    print("=" * 50)
    
    missing = []
    for section in required_sections:
        if section in content:
            print(f"✅ {section}")
        else:
            print(f"❌ 缺失: {section}")
            missing.append(section)
    
    # 检查禁止表述
    forbidden = ["详见完整版", "因篇幅限制", "待补充", "待明确"]
    found_forbidden = []
    for phrase in forbidden:
        if phrase in content:
            found_forbidden.append(phrase)
            print(f"⚠️  发现禁止表述: {phrase}")
    
    # 检查数据溯源
    source_pattern = r'来源：|来源:|数据来源：|依据：'
    sources = re.findall(source_pattern, content)
    print(f"\n📊 数据溯源标注: {len(sources)}处")
    
    print(f"\n📋 检查结果:")
    print(f"  章节完整: {len(missing) == 0}")
    print(f"  禁止表述: {len(found_forbidden) == 0}")
    print(f"  数据溯源: {len(sources)}处")
    
    if missing:
        print(f"\n[FAIL] 缺失章节: {', '.join(missing)}")
        return False
    if found_forbidden:
        print(f"\n[FAIL] 存在禁止表述")
        return False
    
    print(f"\n[PASS] 质量检查通过")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 check-quality.py <报告文件.md>")
        sys.exit(1)
    
    success = check_report(sys.argv[1])
    sys.exit(0 if success else 1)