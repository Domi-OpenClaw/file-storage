#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
百度千帆 web_search API 调用脚本
由 search.py 内部调用，不直接对外暴露
"""

import sys
import json
import os
import requests


def baidu_search(api_key, request_body: dict):
    url = "https://qianfan.baidubce.com/v2/ai_search/web_search"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "X-Appbuilder-From": "openclaw",
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=request_body, headers=headers)
    response.raise_for_status()
    results = response.json()
    if "code" in results:
        raise Exception(results["message"])
    return results.get("references", [])


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: baidu_search.py <Json>")
        sys.exit(1)

    try:
        parse_data = json.loads(sys.argv[1])
    except json.JSONDecodeError as e:
        print(f"JSON parse error: {e}")
        sys.exit(1)

    query = parse_data.get("query", "")
    if not query:
        print("Error: query must be present in request body.")
        sys.exit(1)

    count = min(int(parse_data.get("count", 10)), 50)

    api_key = os.getenv("BAIDU_API_KEY")
    if not api_key:
        print("Error: BAIDU_API_KEY must be set in environment.")
        sys.exit(1)

    request_body = {
        "messages": [{"content": query, "role": "user"}],
        "search_source": "baidu_search_v2",
        "resource_type_filter": [{"type": "web", "top_k": count}],
        "search_filter": {}
    }

    try:
        results = baidu_search(api_key, request_body)
        # 去掉 snippet 字段，节省 token
        for item in results:
            item.pop("snippet", None)
        print(json.dumps(results, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
