---
name: search-routing
description: 统一搜索路由层。封装13个搜索引擎，实现智能路由调度+自动去重+配额保护。所有业务Skill的搜索调用统一走此层，实现搜索能力与业务解耦。DCS层纳管。
version: 1.5.0
author: Domi
created: 2026-04-13
updated: 2026-04-24
---

# search-routing · 统一搜索路由 v1.5

> 业务层只需调用 `search(query, num)`，底层能力持续升级，对业务透明。

---

## 一、核心价值

| 维度 | 升级前 | 升级后 |
|------|--------|--------|
| 引擎数量 | 3个 | **13个** |
| 微信搜索 | 百度50次/天（快速耗尽） | **Sogou微信无限优先** |
| 百度配额 | 主动消耗 | **仅兜底时消耗** |
| 高级语法 | ❌ | **site:/filetype:/tbs:/OR/-排除** |
| 隐私搜索 | ❌ | **DuckDuckGo/Startpage/Brave** |
| 知识计算 | ❌ | **WolframAlpha** |

---

## 二、架构

```
业务 Skill（只调 search(query, num)）
    ↓
search-routing（本层）
    ├── [微信场景] → Sogou微信（无限）→ 百度兜底
    ├── [高级语法] → 专用路由 → 360/搜狗/百度
    ├── [隐私搜索] → DuckDuckGo / Startpage / Brave
    ├── [数学/计算] → WolframAlpha
    ├── [指定引擎] → 单引擎，不聚合
    └── [普通搜索] → MiniMax + SearXNG 聚合
```

---

## 三、支持13个引擎

### 主力层（无限配额，不耗百度配额）

| 引擎 | 用途 | 特点 |
|------|------|------|
| **MiniMax** | 普通搜索 | 无配额限制 |
| **SearXNG** | 普通搜索聚合 | 聚合bing/百度/搜狗/360 |
| **Sogou微信** | 微信文章搜索 | **优先使用**，无限配额 |
| **360** | site/filetype/时间过滤 | 国内URL模板 |
| **搜狗** | 国内普通搜索 | 国内URL模板 |
| **头条搜索** | 国内新闻/资讯 | 国内URL模板 |
| **集思录** | 财经话题/论坛 | 财经专用 |

### 隐私层（无限配额）

| 引擎 | 用途 | 特点 |
|------|------|------|
| **DuckDuckGo** | 隐私搜索 | 无追踪 |
| **Startpage** | 隐私搜索 | Google结果+隐私 |
| **Brave** | 隐私搜索 | 独立索引 |

### 知识层（无限配额）

| 引擎 | 用途 | 特点 |
|------|------|------|
| **WolframAlpha** | 数学/汇率/股票 | 计算类query自动路由 |

### 兜底层（50次/天配额，战略储备）

| 引擎 | 用途 | 触发条件 |
|------|------|---------|
| **百度API** | 兜底+补充 | Sogou微信失败 / 全局兜底 / 对接人信息补充 |

---

## 四、智能路由规则

### 路由优先级

```
① 微信场景
   → Sogou微信（优先，无限）
   → 百度API兜底（消耗配额）

② 高级语法（site:/filetype:/tbs:/OR/-）
   → 解析后路由到最适合引擎组合
   → 百度作为filetype场景的最终兜底

③ 数学/计算类query
   → WolframAlpha（自动识别）

④ 指定引擎（preferred_engine参数）
   → 单引擎，不走聚合

⑤ 普通搜索
   → MiniMax + SearXNG 聚合（合并去重）

⑥ 全局兜底
   → 百度API（消耗配额）
```

### 百度配额消耗策略

**仅在以下3种场景消耗百度50次/天配额**：

| 场景 | 消耗配额？ | 说明 |
|------|----------|------|
| Sogou微信搜不到 | ✅ 消耗1次 | 微信场景兜底 |
| 所有引擎全失败 | ✅ 消耗1次 | 全局兜底 |
| 指定引擎失败 | ❌ 不消耗 | 只记录引擎失败 |

**效果**：百度配额从"日常消耗"变为"战略储备"，可用天数从1天延长到按需使用。

---

## 五、高级搜索语法

### 支持的操作符

| 语法 | 示例 | 说明 |
|------|------|------|
| `site:` | `site:github.com 虚拟电厂` | 限定站点 |
| `filetype:` | `filetype:pdf 储能规则` | 限定文件类型 |
| `tbs=qdr:w` | `tbs=qdr:w 电力政策` | 时间过滤（过去一周） |
| `tbs=qdr:m` | `tbs=qdr:m 市场报告` | 时间过滤（过去一月） |
| `OR` | `虚拟电厂 OR VPP` | 多词组合 |
| `-词` | `储能 -锂电池` | 排除词 |

### 时间过滤器（tbs参数）

| 参数 | 含义 |
|------|------|
| `qdr:h` | 过去一小时 |
| `qdr:d` | 过去一天 |
| `qdr:w` | 过去一周 |
| `qdr:m` | 过去一月 |
| `qdr:y` | 过去一年 |

---

## 六、使用示例

### 6.1 Python 调用（业务Skill标准方式）

```python
import sys
sys.path.insert(0, "/home/admin/.openclaw/skills/search-routing/scripts")
from search import search

# 普通搜索
results = search("虚拟电厂 2026", num=10)

# 指定引擎
results = search("储能政策", num=5, preferred_engine="360")

# 微信文章搜索
results = search("site:mp.weixin.qq.com 虚拟电厂", num=10)

# 带时间过滤
results = search("tbs=qdr:w 电力市场规则", num=10)
```

### 6.2 CLI 调用

```bash
# 普通搜索（默认聚合）
python3 ~/.openclaw/skills/search-routing/scripts/search.py "虚拟电厂 2026" 10

# 微信文章搜索
python3 ~/.openclaw/skills/search-routing/scripts/search.py "site:mp.weixin.qq.com 虚拟电厂"

# 指定引擎
python3 ~/.openclaw/skills/search-routing/scripts/search.py --engine 360 "储能政策"

# 时间过滤
python3 ~/.openclaw/skills/search-routing/scripts/search.py --tbs qdr:w "电力政策"

# 状态查询
python3 ~/.openclaw/skills/search-routing/scripts/search.py --status
```

### 6.3 场景示例

| 场景 | 推荐方式 | 说明 |
|------|---------|------|
| 搜索微信文章 | `search("site:mp.weixin.qq.com 关键词")` | Sogou微信优先 |
| 搜索政策PDF | `search("filetype:pdf 储能规则 2026")` | 自动路由到百度兜底 |
| 搜索GitHub代码 | `search("site:github.com 虚拟电厂")` | 自动路由到DuckDuckGo |
| 搜索近期新闻 | `search("--tbs qdr:w 关键词")` | 时间过滤 |
| 汇率换算 | `search("100 USD to CNY")` | 自动路由到WolframAlpha |
| 搜索财经话题 | `search("关键词", preferred_engine="jisilu")` | 集思录财经专用 |
| 隐私搜索 | `search("关键词", preferred_engine="duckduckgo")` | 无追踪 |

---

## 七、返回格式

```json
[
  {
    "title": "标题",
    "url": "https://...",
    "content": "摘要内容..."
  },
  ...
]
```

字段说明：
- `title`：结果标题
- `url`：原始链接
- `content`：摘要片段（无摘要时为空字符串）

---

## 八、状态查询

```bash
python3 ~/.openclaw/skills/search-routing/scripts/search.py --status
```

```json
{
  "date": "2026-04-24",
  "baidu_count": 3,
  "baidu_limit": 50,
  "baidu_available": true,
  "active_engine": "auto",
  "engines": {
    "minimax": {"name": "MiniMax联网搜索", "enabled": true},
    "searxng": {"name": "SearXNG聚合搜索", "enabled": true},
    "baidu": {"name": "百度搜索API", "enabled": true},
    "sogou_wechat": {"name": "搜狗微信搜索", "enabled": true},
    "360": {"name": "360搜索", "enabled": true},
    "sogou": {"name": "搜狗搜索", "enabled": true},
    "toutiao": {"name": "头条搜索", "enabled": true},
    "jisilu": {"name": "集思录", "enabled": true},
    "duckduckgo": {"name": "DuckDuckGo隐私搜索", "enabled": true},
    "startpage": {"name": "Startpage隐私搜索", "enabled": true},
    "brave": {"name": "Brave搜索", "enabled": true},
    "wolframalpha": {"name": "WolframAlpha知识计算", "enabled": true}
  }
}
```

---

## 九、接入新业务Skill

```python
# ✅ 正确方式
import sys
sys.path.insert(0, "/home/admin/.openclaw/skills/search-routing/scripts")
from search import search
results = search("关键词")

# ❌ 禁止（业务Skill直接调用搜索）
subprocess.run(["python3", "baidu-search/scripts/search.py", ...])
```

---

## 十、环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `BAIDU_API_KEY` | （空） | 百度千帆API Key，不设置则无百度功能 |
| `BAIDU_DAILY_LIMIT` | `50` | 每日配额上限 |
| `SEARXNG_URL` | `http://127.0.0.1:8080/search` | SearXNG端点 |

---

## 十一、扩展新搜索引擎

在 `ENGINES` 字典注册，并在 `_do_search()` 添加分发逻辑：

```python
# 1. 在 ENGINES 注册
ENGINES = {
    # ... 现有引擎 ...
    "新引擎": {"name": "新引擎名称", "enabled": True, "region": "cn"},
}

# 2. 在 _do_search() 添加
def _do_search(engine_key, query, num):
    dispatch = {
        # ... 现有引擎 ...
        "新引擎": lambda: _search_新引擎(query, num),
    }
```

---

## 十二、版本历史

| 版本 | 日期 | 更新内容 |
|------|------|---------|
| v1.0 | 2026-04-13 | 初始版本（MiniMax/SearXNG/百度） |
| v1.4 | 2026-04-20 | 聚合去重、微信场景绿色通道 |
| **v1.5** | **2026-04-24** | **融合multi-search-engine：新增9个引擎、高级语法、隐私搜索、百度配额保护** |

---

*search-routing v1.5 · 2026-04-24 · 融合 multi-search-engine 高级能力*
