#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
search-routing · 统一搜索路由层 v1.5
封装多搜索引擎，统一实现配额限制 + 自动路由调度

路由规则（2026-04-24 增强版）：
  ① 微信场景 → Sogou微信（优先，无限）→ 百度API兜底（配额50/天）
  ② 对接人信息 → MiniMax + SearXNG → 百度API补充（配额控制）
  ③ 高级语法（site:/filetype:/tbs:）→ 解析后路由到最适合引擎
  ④ 隐私搜索 → DuckDuckGo / Startpage / Brave
  ⑤ 数学/计算 → WolframAlpha
  ⑥ 普通搜索 → MiniMax + SearXNG 聚合搜索 → 合并去重
  ⑦ 百度配额：仅用于兜底和补充，不主动消耗
"""

import os
import re
import sys
import json
import datetime
import subprocess
import urllib.request
import urllib.parse

# ─── 基础配置 ────────────────────────────────────────────────
BAIDU_API_KEY = os.getenv("BAIDU_API_KEY", "")
SEARXNG_URL = os.getenv("SEARXNG_URL", "http://127.0.0.1:8080/search")
BAIDU_DAILY_LIMIT = int(os.getenv("BAIDU_DAILY_LIMIT", "50"))

# 搜索引擎注册表
ENGINES = {
    "minimax": {
        "name": "MiniMax联网搜索",
        "enabled": True,
        "region": "all",
    },
    "searxng": {
        "name": "SearXNG聚合搜索",
        "enabled": True,
        "region": "all",
    },
    "baidu": {
        "name": "百度搜索API",
        "enabled": bool(BAIDU_API_KEY),
        "region": "all",
    },
    "sogou_wechat": {
        "name": "搜狗微信搜索",
        "enabled": True,
        "region": "wechat",
    },
    "360": {
        "name": "360搜索",
        "enabled": True,
        "region": "cn",
    },
    "sogou": {
        "name": "搜狗搜索",
        "enabled": True,
        "region": "cn",
    },
    "toutiao": {
        "name": "头条搜索",
        "enabled": True,
        "region": "cn",
    },
    "jisilu": {
        "name": "集思录",
        "enabled": True,
        "region": "cn",
    },
    "duckduckgo": {
        "name": "DuckDuckGo隐私搜索",
        "enabled": True,
        "region": "global",
    },
    "startpage": {
        "name": "Startpage隐私搜索",
        "enabled": True,
        "region": "global",
    },
    "brave": {
        "name": "Brave搜索",
        "enabled": True,
        "region": "global",
    },
    "wolframalpha": {
        "name": "WolframAlpha知识计算",
        "enabled": True,
        "region": "knowledge",
    },
}

_active_engine = None


# ─── 配额持久化 ──────────────────────────────────────────────

def _quota_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "_quota_tracker.json")


def _load_quota():
    today = datetime.date.today().strftime("%Y-%m-%d")
    try:
        with open(_quota_path(), "r") as f:
            obj = json.load(f)
        if obj.get("date") == today:
            return today, int(obj.get("count", 0))
        return today, 0
    except (FileNotFoundError, json.JSONDecodeError):
        return today, 0


def _save_quota(date_str, count):
    with open(_quota_path(), "w") as f:
        json.dump({"date": date_str, "count": count}, f)


def _baidu_is_available():
    today, count = _load_quota()
    return count < BAIDU_DAILY_LIMIT


def _use_baidu_quota():
    """消费一次百度配额，返回是否成功（超配额则不消耗直接返回False）"""
    today, count = _load_quota()
    if count >= BAIDU_DAILY_LIMIT:
        return False
    _save_quota(today, count + 1)
    return True


# ─── 高级搜索操作符解析 ──────────────────────────────────────

def _parse_advanced_query(query):
    """
    解析高级搜索操作符，返回 (clean_keyword, meta)
    支持：site: filetype: tbs: OR -排除
    """
    meta = {
        "site": None,
        "filetype": None,
        "tbs": None,
        "exclude": [],
        "or_terms": [],
    }

    # site: 提取
    site_match = re.search(r'site:(\S+)', query)
    if site_match:
        meta["site"] = site_match.group(1)
        query = re.sub(r'site:\S+', '', query).strip()

    # filetype: 提取
    ft_match = re.search(r'filetype:(\S+)', query)
    if ft_match:
        meta["filetype"] = ft_match.group(1)
        query = re.sub(r'filetype:\S+', '', query).strip()

    # tbs: 时间过滤器提取
    tbs_match = re.search(r'tbs=(qdr:[dhwmy])', query)
    if tbs_match:
        meta["tbs"] = tbs_match.group(1)
        query = re.sub(r'tbs=qdr:[dhwmy]', '', query).strip()

    # OR terms: 提取（虚拟电厂 OR VPP）
    or_pattern = re.compile(r'"([^"]+)"\s+OR\s+"([^"]+)"')
    or_match = or_pattern.search(query)
    if or_match:
        meta["or_terms"] = [or_match.group(1), or_match.group(2)]
        query = or_pattern.sub('', query).strip()

    # -排除词
    exclude_matches = re.findall(r'-(\S+)', query)
    if exclude_matches:
        meta["exclude"] = exclude_matches
        query = re.sub(r'-\S+', '', query).strip()

    return query.strip(), meta


def _filter_excluded(results, exclude_terms):
    """根据排除词过滤结果"""
    if not exclude_terms:
        return results
    filtered = []
    for item in results:
        text = (item.get("title", "") + item.get("content", "")).lower()
        if not any(term.lower() in text for term in exclude_terms):
            filtered.append(item)
    return filtered


# ─── 各搜索引擎实现 ──────────────────────────────────────────

def _build_360_url(query, tbs=None):
    base = f"https://www.so.com/s?q={urllib.parse.quote(query)}"
    if tbs:
        base += f"&e={tbs}"
    return base


def _build_sogou_url(query, tbs=None):
    base = f"https://www.sogou.com/web?query={urllib.parse.quote(query)}"
    if tbs:
        base += f"&e={tbs}"
    return base


def _build_toutiao_url(query):
    return f"https://so.toutiao.com/search?keyword={urllib.parse.quote(query)}"


def _build_jisilu_url(query):
    return f"https://www.jisilu.cn/explore/?keyword={urllib.parse.quote(query)}"


def _build_wolframalpha_url(query):
    return f"https://www.wolframalpha.com/input?i={urllib.parse.quote(query)}"


def _fetch_webpage(url, timeout=30):
    """通用网页抓取（用于URL模板引擎）"""
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (compatible; DomiBot/1.5; +https://openclaw.ai)"
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            charset = "utf-8"
            content_type = resp.headers.get("Content-Type", "")
            if "charset=" in content_type:
                charset = content_type.split("charset=")[-1]
            html = resp.read().decode(charset, errors="replace")
        return html
    except Exception as e:
        print(f"[fetch] {url[:60]} 失败: {e}", flush=True)
        return ""


def _extract_search_results(html, engine_hint=None):
    """
    从HTML中提取搜索结果（通用摘要提取）
    适用于360/搜狗/头条/集思录/DuckDuckGo等
    """
    results = []
    # 通用title+href提取（简化实现）
    title_pattern = re.compile(r'<h3[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([^<]+)</a>', re.IGNORECASE)
    snippet_pattern = re.compile(r'<p[^>]*class="[^"]*desc[^"]*"[^>]*>([^<]+)</p>', re.IGNORECASE)

    for match in title_pattern.finditer(html):
        url, title = match.group(1), match.group(2)
        title = re.sub(r'<[^>]+>', '', title).strip()
        if title and url.startswith("http"):
            snippet = ""
            # 尝试在title附近找snippet
            start = match.end()
            snippet_match = snippet_pattern.search(html[start:start+500])
            if snippet_match:
                snippet = re.sub(r'<[^>]+>', '', snippet_match.group(1)).strip()
            results.append({"title": title, "url": url, "content": snippet})
            if len(results) >= 20:
                break
    return results


def _search_template_engine(query, url_builder, num=10, engine_name="template"):
    """通用URL模板搜索引擎（360/搜狗/头条/集思录等）"""
    url = url_builder(query)
    print(f"[search] {engine_name}: {url[:80]}", flush=True)
    html = _fetch_webpage(url)
    if not html:
        return None
    results = _extract_search_results(html, engine_name)
    print(f"[search] {engine_name} 返回 {len(results)} 条", flush=True)
    return results[:num]


def _search_wolframalpha(query, num=5):
    """WolframAlpha 知识计算"""
    url = _build_wolframalpha_url(query)
    print(f"[search] WolframAlpha: {url[:80]}", flush=True)
    html = _fetch_webpage(url)
    if not html:
        return None
    # 提取计算结果
    results = []
    result_pattern = re.compile(r'<script[^>]*>result\s*=\s*"([^"]+)"', re.IGNORECASE)
    pods = re.findall(r'<pod[^>]*title="([^"]+)"[^>]*>.*?<input[^>]*value="([^"]+)"', html, re.DOTALL)
    for pod_title, pod_value in pods[:5]:
        results.append({
            "title": pod_title,
            "url": url,
            "content": pod_value.strip()
        })
    print(f"[search] WolframAlpha 返回 {len(results)} 条", flush=True)
    return results[:num]


def _search_baidu(query, num=10):
    """百度AI搜索 API（严格配额控制）"""
    if not BAIDU_API_KEY:
        print("[search] 百度 BAIDU_API_KEY 未配置，跳过", flush=True)
        return None

    if not _baidu_is_available():
        print(f"[search] 百度配额已用尽({_load_quota()[1]}次)或欠费，跳过", flush=True)
        return None

    today, count = _load_quota()
    print(f"[search] 百度 #{count + 1}/{BAIDU_DAILY_LIMIT}: {query[:30]}", flush=True)

    baidu_script = os.path.expanduser(
        "~/.openclaw/workspace/skills/baidu-search/scripts/search.py"
    )
    cmd = [sys.executable, baidu_script, json.dumps({"query": query, "count": num})]
    env = os.environ.copy()
    env["BAIDU_API_KEY"] = BAIDU_API_KEY
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=30, env=env)
        output = result.stdout.decode("utf-8", errors="replace").strip()
        lines = output.splitlines()
        json_start = next((i for i, l in enumerate(lines) if l.strip().startswith("[")), None)
        if json_start is not None:
            json_str = "\n".join(lines[json_start:])
            try:
                data = json.loads(json_str)
                if isinstance(data, list) and len(data) > 0:
                    _use_baidu_quota()
                    return [{"title": r.get("title", ""), "url": r.get("url", ""),
                             "content": r.get("content", "")} for r in data]
            except json.JSONDecodeError:
                pass
        print(f"[search] 百度格式异常: {output[:100]}", flush=True)
        return None
    except Exception as e:
        print(f"[search] 百度失败: {e}", flush=True)
        return None


def _search_sogou_wechat(query, num=10):
    """搜狗微信搜索（无需APIKey，无配额限制）"""
    url = f"https://wx.sogou.com/weixin?type=2&query={urllib.parse.quote(query)}"
    print(f"[search] 搜狗微信: {url[:80]}", flush=True)
    html = _fetch_webpage(url)
    if not html:
        return None
    # 微信文章提取
    results = []
    title_pattern = re.compile(r'<h3[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([^<]+)</a>', re.IGNORECASE)
    for match in title_pattern.finditer(html):
        url_href, title = match.group(1), match.group(2)
        title = re.sub(r'<[^>]+>', '', title).strip()
        if title and "mp.weixin.qq.com" in url_href:
            results.append({"title": title, "url": url_href, "content": ""})
            if len(results) >= num:
                break
    print(f"[search] 搜狗微信返回 {len(results)} 条", flush=True)
    return results


def _search_searxng(query, num=10):
    """SearXNG 免费聚合搜索（国内可用引擎：bing/百度/搜狗/360等）"""
    params = urllib.parse.urlencode({"q": query, "format": "json",
                                     "count": min(num, 20), "categories": "general"})
    try:
        req = urllib.request.Request(f"{SEARXNG_URL}?{params}",
                                     headers={"User-Agent": "DomiBot/1.5"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
        results = data.get("results", [])
        out = [{"title": r.get("title", ""), "url": r.get("url", ""),
                "content": r.get("content", ""), "engine": r.get("engine", "unknown")}
               for r in results[:num]]
        print(f"[search] SearXNG 返回 {len(out)} 条（参与引擎: {set(r['engine'] for r in out)}）", flush=True)
        return out
    except Exception as e:
        print(f"[search] SearXNG 失败: {e}", flush=True)
        return None


def _search_minimax(query, num=10):
    """MiniMax 联网搜索（via mcporter，无配额限制）"""
    cmd = ["mcporter", "call", "minimax-vision.web_search", f"query={query}"]
    try:
        workspace = os.path.expanduser("~/.openclaw/workspace")
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=30, cwd=workspace)
        raw = result.stdout.decode("utf-8", errors="replace").strip()
        lines = [l for l in raw.splitlines() if not l.startswith("[")]
        json_str = "\n".join(lines)
        if not json_str:
            print(f"[search] MiniMax 空输出", flush=True)
            return None
        data = json.loads(json_str)
        results = data.get("organic", [])
        if results:
            out = [{"title": r.get("title", ""), "url": r.get("link", ""),
                    "content": r.get("snippet", "")} for r in results[:num]]
            print(f"[search] MiniMax 返回 {len(out)} 条", flush=True)
            return out
        return None
    except json.JSONDecodeError as e:
        print(f"[search] MiniMax JSON解析失败: {e}", flush=True)
        return None
    except Exception as e:
        print(f"[search] MiniMax 失败: {e}", flush=True)
        return None


def _deduplicate(results):
    """URL 去重，保留首次出现的条目"""
    seen_urls = set()
    deduped = []
    for item in results:
        url = item.get("url", "")
        if url and url not in seen_urls:
            seen_urls.add(url)
            deduped.append(item)
    return deduped


# ─── 路由分发 ────────────────────────────────────────────────

def _do_search(engine_key, query, num):
    dispatch = {
        "baidu": lambda: _search_baidu(query, num),
        "sogou_wechat": lambda: _search_sogou_wechat(query, num),
        "minimax": lambda: _search_minimax(query, num),
        "searxng": lambda: _search_searxng(query, num),
        "360": lambda: _search_template_engine(query, _build_360_url, num, "360搜索"),
        "sogou": lambda: _search_template_engine(query, _build_sogou_url, num, "搜狗搜索"),
        "toutiao": lambda: _search_template_engine(query, _build_toutiao_url, num, "头条搜索"),
        "jisilu": lambda: _search_template_engine(query, _build_jisilu_url, num, "集思录"),
        "duckduckgo": lambda: _search_template_engine(query,
            lambda q: f"https://duckduckgo.com/html/?q={urllib.parse.quote(q)}", num, "DuckDuckGo"),
        "startpage": lambda: _search_template_engine(query,
            lambda q: f"https://www.startpage.com/sp/search?query={urllib.parse.quote(q)}", num, "Startpage"),
        "brave": lambda: _search_template_engine(query,
            lambda q: f"https://search.brave.com/search?q={urllib.parse.quote(q)}", num, "Brave"),
        "wolframalpha": lambda: _search_wolframalpha(query, num),
    }
    fn = dispatch.get(engine_key)
    if fn:
        return fn()
    return None


def _route_advanced(query, clean_query, meta, num):
    """
    根据高级操作符路由到最适合的引擎
    """
    results = []

    # site: 搜索
    if meta["site"]:
        site = meta["site"]
        # 国内常用站点优先360/搜狗，国际站点优先DuckDuckGo/Startpage
        cn_sites = ["baidu.com", "sina.com", "163.com", "qq.com", "sohu.com",
                     "zhihu.com", "csdn.net", "jianshu.io", "aliyun.com", "cn"]
        if any(s in site for s in cn_sites):
            r = _search_template_engine(clean_query,
                lambda q: f"https://www.so.com/s?q={urllib.parse.quote(q)}+site:{site}", num, "360 site")
            if r: results.extend(r)
            r2 = _search_template_engine(clean_query,
                lambda q: f"https://www.sogou.com/web?query={urllib.parse.quote(q)}+site:{site}", num, "搜狗 site")
            if r2: results.extend(r2)
        else:
            r = _search_template_engine(clean_query,
                lambda q: f"https://duckduckgo.com/html/?q={urllib.parse.quote(q)}+site:{site}", num, "DDG site")
            if r: results.extend(r)

    # filetype: 搜索 → 百度（PDF索引最强）
    if meta["filetype"]:
        ft = meta["filetype"]
        r = _search_template_engine(clean_query,
            lambda q: f"https://www.so.com/s?q={urllib.parse.quote(q)}+filetype:{ft}", num, "360 filetype")
        if r: results.extend(r)
        r2 = _search_template_engine(clean_query,
            lambda q: f"https://www.sogou.com/web?query={urllib.parse.quote(q)}+filetype:{ft}", num, "搜狗 filetype")
        if r2: results.extend(r2)
        # 百度作为兜底（消耗配额）
        if _baidu_is_available():
            r3 = _search_baidu(f"filetype:{ft} {clean_query}", num)
            if r3: results.extend(r3)

    # tbs 时间过滤 → 拼入URL
    if meta["tbs"]:
        tbs = meta["tbs"]
        r = _search_template_engine(clean_query,
            lambda q: _build_360_url(q, tbs), num, "360时间过滤")
        if r: results.extend(r)
        r2 = _search_template_engine(clean_query,
            lambda q: _build_sogou_url(q, tbs), num, "搜狗时间过滤")
        if r2: results.extend(r2)

    return results


def search(query, num=10, preferred_engine=None):
    """
    统一搜索入口 v1.5（2026-04-24 增强版）

    路由规则：
      ① 微信场景 → Sogou微信（优先）→ 百度API兜底
      ② 对接人信息场景 → MiniMax + SearXNG → 百度API补充（消耗配额）
      ③ 高级语法（site:/filetype:/tbs:）→ 解析后路由到最适合引擎
      ④ 隐私搜索 → DuckDuckGo / Startpage / Brave
      ⑤ 数学/计算 → WolframAlpha
      ⑥ 普通搜索 → MiniMax + SearXNG 聚合
    """
    global _active_engine

    # 解析高级操作符
    clean_query, meta = _parse_advanced_query(query)

    # ① 微信场景 → Sogou微信优先 → 百度兜底
    is_wechat = ("site:mp.weixin.qq.com" in query or
                 "mp.weixin.qq.com" in query or
                 "微信" in query)
    if is_wechat:
        result = _search_sogou_wechat(clean_query, num)
        if result:
            _active_engine = "sogou_wechat"
            filtered = _filter_excluded(result, meta["exclude"])
            return _deduplicate(filtered)
        # Sogou搜不到，尝试百度兜底
        if _baidu_is_available():
            result2 = _search_baidu(query, num)
            if result2:
                _active_engine = "baidu"
                return _deduplicate(_filter_excluded(result2, meta["exclude"]))
        return []

    # ② 高级语法 → 专用路由
    if any([meta["site"], meta["filetype"], meta["tbs"]]):
        results = _route_advanced(query, clean_query, meta, num)
        if results:
            _active_engine = "advanced"
            return _deduplicate(_filter_excluded(results, meta["exclude"]))

    # ③ 数学/计算 → WolframAlpha
    is_math = any(k in query for k in ["=", "+", "-", "*", "/", "to ", "convert ",
                                         "人民币", "美元", "欧元", "汇率", "积分", "求导", "积分",
                                         "°", "kg", "cm", "km", "USD", "CNY"])
    if is_math:
        result = _search_wolframalpha(query, num)
        if result:
            _active_engine = "wolframalpha"
            return result

    # ④ 指定引擎（不走聚合）
    if preferred_engine and preferred_engine in ENGINES and ENGINES[preferred_engine].get("enabled"):
        result = _do_search(preferred_engine, clean_query, num)
        if result is not None:
            _active_engine = preferred_engine
            return _deduplicate(_filter_excluded(result, meta["exclude"]))

    # ⑤ 普通搜索 → MiniMax + SearXNG 聚合
    all_results = []
    for key in ["minimax", "searxng"]:
        eng = ENGINES[key]
        if not eng.get("enabled"):
            continue
        result = _do_search(key, clean_query, num)
        if result:
            all_results.extend(result)
            _active_engine = key

    if all_results:
        return _deduplicate(_filter_excluded(all_results, meta["exclude"]))

    # ⑥ 全都失败 → 百度兜底（消耗配额）
    if _baidu_is_available():
        result = _search_baidu(clean_query, num)
        if result:
            _active_engine = "baidu"
            return _deduplicate(_filter_excluded(result, meta["exclude"]))

    return []


def get_status():
    today, count = _load_quota()
    return {
        "date": today,
        "baidu_count": count,
        "baidu_limit": BAIDU_DAILY_LIMIT,
        "baidu_available": _baidu_is_available(),
        "active_engine": _active_engine or "auto",
        "engines": {k: {"name": v["name"], "enabled": v.get("enabled", False), "region": v.get("region")}
                    for k, v in ENGINES.items()},
    }


# ─── CLI 入口 ────────────────────────────────────────────────

if __name__ == "__main__":
    args = sys.argv[1:]

    if "--status" in args:
        print(json.dumps(get_status(), indent=2, ensure_ascii=False))
        sys.exit(0)

    engine = None
    if "--engine" in args:
        idx = args.index("--engine")
        engine = args[idx + 1]
        args = args[:idx] + args[idx + 2:]

    # 时间过滤参数
    tbs_param = None
    if "--tbs" in args:
        idx = args.index("--tbs")
        tbs_param = args[idx + 1]
        args = args[:idx] + args[idx + 2:]

    if not args:
        print("用法: search.py [--engine eng] [--tbs qdr:w] <query> [num]")
        print("示例: search.py --tbs qdr:w 储能政策")
        print("      search.py --engine 360 site:github.com python")
        print("      search.py 虚拟电厂 OR VPP")
        sys.exit(1)

    query = args[0]
    if tbs_param:
        query = f"tbs={tbs_param} {query}"

    num = int(args[1]) if len(args) > 1 else 10
    results = search(query, num, preferred_engine=engine)
    print(json.dumps(results, ensure_ascii=False, indent=2))
