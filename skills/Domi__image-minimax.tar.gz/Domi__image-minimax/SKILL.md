---
id: Domi/image-minimax
owner_id: Domi
name: image-minimax
description: 使用 MiniMax understand_image API 进行图像理解。传入图片路径，返回 AI 对图片的描述。
version: 1.0.0
icon: 🖼️
author: Domi
---

# MiniMax 图像理解

基于 MiniMax Token Plan 的 `understand_image` API，封装成本地脚本供 OpenClaw 调用。

## 环境要求

- Python 3.7+
- 需要 `openai-whisper` 已安装（用于获取 Python 环境）

## 使用方法

### 命令行

```bash
python3 ~/.openclaw/skills/Domi__image-minimax/understand_image.py <图片路径> [prompt]
```

### Python 调用

```python
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))
from understand_image import understand_image

result = understand_image("/path/to/image.jpg", "这张图片里有什么？")
print(result)
```

## 参数

- `图片路径`：本地图片的绝对路径，支持 JPEG、PNG、WebP
- `prompt`：可选，自定义提问；默认 "描述这张图片的内容"

## 返回

返回图片的 AI 描述文字。

## 依赖

- MiniMax API Key（已硬编码在脚本中）
- Python 3.7+
