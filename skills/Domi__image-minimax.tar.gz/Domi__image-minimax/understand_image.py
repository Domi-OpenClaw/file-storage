#!/usr/bin/env python3
"""MiniMax understand_image 封装脚本"""
import sys
import json
import base64
import urllib.request
import os

API_KEY = "sk-cp-LmnsUkyfTz-migHWuEXmxr91x91nbcdz9jjcAawKazAVat7m1SzaDZvE_OhvA_9plxDTnLmXgJEyqpkJG4NIQ0syoUWjQ9tcV0EebeQ78W17XP05-XwCixA"
API_HOST = "https://api.minimaxi.com"

def process_image(image_path):
    """处理本地图片为base64"""
    with open(image_path, 'rb') as f:
        data = f.read()
    return f"data:image/jpeg;base64,{base64.b64encode(data).decode()}"

def understand_image(image_path, prompt="描述这张图片的内容"):
    """调用MiniMax understand_image API"""
    if not os.path.exists(image_path):
        return f"错误：图片文件不存在: {image_path}"
    
    image_url = process_image(image_path)
    
    url = f"{API_HOST}/v1/coding_plan/vlm"
    payload = {
        "prompt": prompt,
        "image_url": image_url
    }
    
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    })
    
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode())
            if "content" in result:
                return result["content"]
            return json.dumps(result, ensure_ascii=False, indent=2)
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        return f"HTTP错误 {e.code}: {body}"
    except Exception as e:
        return f"错误: {str(e)}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: understand_image.py <图片路径> [prompt]")
        sys.exit(1)
    
    image_path = sys.argv[1]
    prompt = sys.argv[2] if len(sys.argv) > 2 else "描述这张图片的内容"
    
    result = understand_image(image_path, prompt)
    print(result)
