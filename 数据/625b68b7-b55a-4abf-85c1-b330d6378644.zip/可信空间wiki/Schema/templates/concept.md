---
type: concept
status: draft
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources: []
---

# 概念名

## 定义


## 关键特征

- 

## 与相邻概念的区别

- 

## 来源依据

- 

## 相关页面

- 

## 待核验

- 

