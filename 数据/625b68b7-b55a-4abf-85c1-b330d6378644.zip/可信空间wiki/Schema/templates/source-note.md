---
type: source-note
status: draft
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources:
  - Raw/...
---

# 来源标题

## 一句话结论

用一句话说明这份资料对 wiki 的主要贡献。

## 基本信息

- 文件路径：
- 文件类型：
- 发布/版本日期：
- 发布机构：
- 状态：正式 / 征求意见稿 / 待核验

## 结构摘要

- 

## 关键要点

- 

## 重要术语

- 

## 可引用摘录

> 仅摘录必要短句，并标注页码或位置；无法确认页码时标为待核验。

## 影响的 wiki 页面

- 

## 冲突或待核验

- 

