#!/usr/bin/env python3
"""从 Raw/*.pdf 生成 Wiki/01_来源笔记 下的 Markdown（含机器抽取正文）。"""
from __future__ import annotations

import re
from pathlib import Path
from datetime import date

from pypdf import PdfReader

WIKI_ROOT = Path(__file__).resolve().parents[1]
RAW = WIKI_ROOT / "Raw"
OUT = WIKI_ROOT / "Wiki" / "01_来源笔记"
TODAY = date.today().isoformat()


def extract_pdf(path: Path) -> tuple[str, int]:
    r = PdfReader(str(path))
    parts: list[str] = []
    for page in r.pages:
        parts.append(page.extract_text() or "")
    text = "\n\n".join(parts)
    text = re.sub(r"\r\n?", "\n", text)
    return text, len(r.pages)


def fence_body(text: str) -> str:
    """保留原文；围栏长度在输出阶段动态加长。"""
    return text


def fenced_code_block(text: str) -> str:
    """用足够长的 ``` 围栏包裹，避免正文中的反引号序列破坏结构。"""
    longest = 0
    for m in re.finditer(r"`+", text):
        longest = max(longest, len(m.group(0)))
    n = max(3, longest + 1)
    ch = "`" * n
    return f"{ch}\n{text}\n{ch}"


def one_liner(text: str, fallback: str) -> str:
    t = re.sub(r"\s+", " ", text).strip()
    if len(t) < 20:
        return fallback
    # 取首个较长句段
    for end in ["。", "；", ".", ";"]:
        i = t.find(end)
        if 30 <= i <= 200:
            return t[: i + 1]
    return t[:180] + ("…" if len(t) > 180 else "")


def toc_bullets(text: str, limit: int = 12) -> list[str]:
    lines = text.splitlines()
    out: list[str] = []
    for line in lines[:400]:
        s = line.strip()
        if not s or len(s) > 120:
            continue
        if re.search(r"\.{3,}", s) and re.match(r"^[\dIVXLC\s\.、．]+", s):
            out.append(s[:100])
        if len(out) >= limit:
            break
    if not out:
        for s in lines[:80]:
            s = s.strip()
            if re.match(r"^(\d+(\.\d+)*|[一二三四五六七八九十]+)[\s\.、．]", s) and 5 < len(s) < 100:
                out.append(s)
            if len(out) >= limit:
                break
    return out[:limit]


def key_snippets(text: str, n: int = 8) -> list[str]:
    chunks = re.split(r"[。\n]", text)
    seen = set()
    res: list[str] = []
    for c in chunks:
        c = re.sub(r"\s+", "", c)
        if 25 <= len(c) <= 120 and c not in seen:
            seen.add(c)
            res.append(c)
        if len(res) >= n:
            break
    return res


def build_note(
    *,
    rel_raw: str,
    title: str,
    doc_type: str,
    status_label: str,
    org: str,
    version_date: str,
    fallback_one_liner: str,
    tags: list[str],
    impacts: list[str],
    text: str,
    pages: int,
    extraction_note: str | None = None,
) -> str:
    ol = one_liner(text, fallback_one_liner)
    struct = toc_bullets(text)
    if not struct:
        struct = ["（未从抽取文本中可靠识别目录行；请以 PDF 为准。）"]
    keys = key_snippets(text)
    if not keys:
        keys = ["（抽取文本过短，无法自动提炼要点。）"]
    excerpt = ""
    for c in keys:
        if len(c) >= 20:
            excerpt = c[:90]
            break
    body = fence_body(text)
    tags_yaml = "\n".join(f"  - {t}" for t in tags) if tags else "  []"
    sources_yaml = f'  - "{rel_raw}"'

    extra = ""
    if extraction_note:
        extra = f"\n\n> **抽取说明**：{extraction_note}\n"

    return f"""---
type: source-note
status: active
created: {TODAY}
updated: {TODAY}
tags:
{tags_yaml}
sources:
{sources_yaml}
---

# {title}

## 一句话结论

{ol}

## 基本信息

- 文件路径：`{rel_raw}`
- 文件类型：PDF
- 发布/版本日期：{version_date}
- 发布机构：{org}
- 状态：{status_label}
- 页数（PDF）：{pages}
- 抽取字符数：{len(text)}
{extra}
## 结构摘要（机器从正文推测，不保真）

{chr(10).join("- " + s for s in struct)}

## 关键要点（机器摘录，需人工核对）

{chr(10).join("- " + s for s in keys)}

## 重要术语

- （请结合 PDF 与下文抽取正文核对术语表与定义。）

## 可引用摘录

> {excerpt if excerpt else "待核验：抽取文本过短，请直接查阅 PDF。"}

## 影响的 wiki 页面

{chr(10).join(f"- [[{p}]]" for p in impacts)}

## 冲突或待核验

- 正文为机器抽取，版式、页码、图表与公式可能丢失；引用请以 `Raw` 原件为准。

## 抽取正文（机器抽取）

以下内容由 `pypdf` 从 PDF 抽取，**不等同于**官方排版文本。

{fenced_code_block(body)}
"""


SPECS: list[dict] = [
    {
        "raw": "Raw/政策/可信空间/可信数据空间发展行动计划（2024—2028年）.pdf",
        "wiki_file": "2024-可信数据空间发展行动计划.md",
        "title": "可信数据空间发展行动计划（2024—2028年）",
        "doc_type": "policy",
        "status_label": "正式（以 PDF 为准）",
        "org": "待核验（见 PDF 发文机关）",
        "version_date": "2024—2028（计划期）",
        "one_liner_fb": "国家层面关于可信数据空间建设与数据要素流通的行动计划。",
        "tags": ["可信数据空间", "政策", "行动计划"],
        "impacts": ["可信数据空间", "可信数据空间政策与标准清单", "可信空间知识地图"],
    },
    {
        "raw": "Raw/政策/可信空间/可信数据空间 能力要求.pdf",
        "wiki_file": "2025-可信数据空间能力要求-TDSA-A-001.md",
        "title": "可信数据空间 能力要求（TDSA/A-001-2025）",
        "doc_type": "standard",
        "status_label": "团体标准（以 PDF 为准）",
        "org": "可信数据空间发展联盟（以 PDF 为准）",
        "version_date": "2025-07-01（以 PDF 为准）",
        "one_liner_fb": "团体标准：规定可信数据空间的能力要求。",
        "tags": ["可信数据空间", "团体标准", "能力要求"],
        "impacts": ["可信数据空间", "可信数据空间政策与标准清单", "接入连接器", "使用控制", "数字合约"],
    },
    {
        "raw": "Raw/政策/可信空间/可信数据空间标准体系建设指南（2025年版）.pdf",
        "wiki_file": "2025-可信数据空间标准体系建设指南.md",
        "title": "可信数据空间标准体系建设指南（2025年版）",
        "doc_type": "guide",
        "status_label": "正式（以 PDF 为准）",
        "org": "待核验（见 PDF）",
        "version_date": "2025年版",
        "one_liner_fb": "可信数据空间标准体系建设的指南性文件。",
        "tags": ["可信数据空间", "标准体系", "指南"],
        "impacts": ["可信数据空间", "可信数据空间政策与标准清单"],
        "extraction_note": "本 PDF 抽取文本极少，可能主要为扫描图片版；**请以原件为准**，后续可 OCR 补全。",
    },
    {
        "raw": "Raw/政策/数据基础设施标准202503/国家数据基础设施技术文件：数据基础设施 参考架构-NDI-TR-2025-01.pdf",
        "wiki_file": "NDI-TR-2025-01-数据基础设施参考架构.md",
        "title": "数据基础设施 参考架构（NDI-TR-2025-01）",
        "doc_type": "tech_file",
        "status_label": "国家数据基础设施技术文件（以 PDF 为准）",
        "org": "待核验（见 PDF 编制/发布单位）",
        "version_date": "2025（以 PDF 为准）",
        "one_liner_fb": "给出国家数据基础设施参考架构。",
        "tags": ["数据基础设施", "NDI", "参考架构"],
        "impacts": ["数据基础设施", "可信数据空间政策与标准清单", "可信数据空间与数据基础设施概览"],
    },
    {
        "raw": "Raw/政策/数据基础设施标准202503/国家数据基础设施技术文件：数据基础设施 互联互通基本要求-NDI-TR-2025-02.pdf",
        "wiki_file": "NDI-TR-2025-02-数据基础设施互联互通基本要求.md",
        "title": "数据基础设施 互联互通基本要求（NDI-TR-2025-02）",
        "doc_type": "tech_file",
        "status_label": "国家数据基础设施技术文件（以 PDF 为准）",
        "org": "待核验（见 PDF）",
        "version_date": "2025",
        "one_liner_fb": "规定数据基础设施互联互通的基本要求。",
        "tags": ["数据基础设施", "互联互通", "NDI"],
        "impacts": ["数据基础设施", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施标准202503/国家数据基础设施技术文件：数据基础设施 用户身份管理和接入规范-NDI-TR-2025-03.pdf",
        "wiki_file": "NDI-TR-2025-03-数据基础设施用户身份管理和接入规范.md",
        "title": "数据基础设施 用户身份管理和接入规范（NDI-TR-2025-03）",
        "doc_type": "tech_file",
        "status_label": "国家数据基础设施技术文件（以 PDF 为准）",
        "org": "待核验（见 PDF）",
        "version_date": "2025",
        "one_liner_fb": "用户身份管理与接入相关规范。",
        "tags": ["数据基础设施", "身份", "接入", "NDI"],
        "impacts": ["数据基础设施", "用户身份管理和接入", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施标准202503/国家数据基础设施技术文件：数据基础设施 标识管理规范-NDI-TR-2025-04.pdf",
        "wiki_file": "NDI-TR-2025-04-数据基础设施标识管理规范.md",
        "title": "数据基础设施 标识管理规范（NDI-TR-2025-04）",
        "doc_type": "tech_file",
        "status_label": "国家数据基础设施技术文件（以 PDF 为准）",
        "org": "待核验（见 PDF）",
        "version_date": "2025",
        "one_liner_fb": "标识管理相关规范。",
        "tags": ["数据基础设施", "标识", "NDI"],
        "impacts": ["数据基础设施", "标识管理", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施标准202503/国家数据基础设施技术文件：数据基础设施 接入连接器技术要求-NDI-TR-2025-05.pdf",
        "wiki_file": "NDI-TR-2025-05-数据基础设施接入连接器技术要求.md",
        "title": "数据基础设施 接入连接器技术要求（NDI-TR-2025-05）",
        "doc_type": "tech_file",
        "status_label": "国家数据基础设施技术文件（以 PDF 为准）",
        "org": "待核验（见 PDF）",
        "version_date": "2025",
        "one_liner_fb": "接入连接器技术要求。",
        "tags": ["数据基础设施", "接入连接器", "NDI"],
        "impacts": ["数据基础设施", "接入连接器", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施标准202503/国家数据基础设施技术文件：数据基础设施 数据基础设施 数据目录描述规范-NDI-TR-2025-06.pdf",
        "wiki_file": "NDI-TR-2025-06-数据基础设施数据目录描述规范.md",
        "title": "数据基础设施 数据目录描述规范（NDI-TR-2025-06）",
        "doc_type": "tech_file",
        "status_label": "国家数据基础设施技术文件（以 PDF 为准）",
        "org": "待核验（见 PDF）",
        "version_date": "2025",
        "one_liner_fb": "数据目录描述规范。",
        "tags": ["数据基础设施", "数据目录", "NDI"],
        "impacts": ["数据基础设施", "数据目录", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施+可信空间202508/1.技术文件-《数据基础设施 区域：行业功能节点技术要求（征求意见稿）》.pdf",
        "wiki_file": "TC609-202508-区域行业功能节点技术要求-征求意见稿.md",
        "title": "数据基础设施 区域/行业功能节点技术要求（征求意见稿）",
        "doc_type": "draft",
        "status_label": "征求意见稿（TC609，以 PDF 为准）",
        "org": "全国数据标准化技术委员会（以 PDF 为准）",
        "version_date": "2025-08（以文件夹与 PDF 为准）",
        "one_liner_fb": "区域/行业功能节点技术要求征求意见稿。",
        "tags": ["数据基础设施", "功能节点", "征求意见稿", "TC609"],
        "impacts": ["数据基础设施", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施+可信空间202508/2.技术文件-《数据基础设施 接入管理（征求意见稿）》.pdf",
        "wiki_file": "TC609-202508-数据基础设施接入管理-征求意见稿.md",
        "title": "数据基础设施 接入管理（征求意见稿）",
        "doc_type": "draft",
        "status_label": "征求意见稿（TC609）",
        "org": "全国数据标准化技术委员会（以 PDF 为准）",
        "version_date": "2025-08",
        "one_liner_fb": "数据基础设施接入管理征求意见稿。",
        "tags": ["数据基础设施", "接入管理", "征求意见稿"],
        "impacts": ["数据基础设施", "用户身份管理和接入", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施+可信空间202508/3.技术文件-《数据基础设施 安全能力通用要求（征求意见稿）》.pdf",
        "wiki_file": "TC609-202508-数据基础设施安全能力通用要求-征求意见稿.md",
        "title": "数据基础设施 安全能力通用要求（征求意见稿）",
        "doc_type": "draft",
        "status_label": "征求意见稿（TC609）",
        "org": "全国数据标准化技术委员会（以 PDF 为准）",
        "version_date": "2025-08",
        "one_liner_fb": "数据基础设施安全能力通用要求征求意见稿。",
        "tags": ["数据基础设施", "安全", "征求意见稿"],
        "impacts": ["数据基础设施", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施+可信空间202508/4.技术文件-《可信数据空间 数字合约技术要求（征求意见稿）》.pdf",
        "wiki_file": "TC609-202508-可信数据空间数字合约技术要求-征求意见稿.md",
        "title": "可信数据空间 数字合约技术要求（征求意见稿）",
        "doc_type": "draft",
        "status_label": "征求意见稿（TC609）",
        "org": "全国数据标准化技术委员会（以 PDF 为准）",
        "version_date": "2025-08",
        "one_liner_fb": "可信数据空间数字合约技术要求征求意见稿。",
        "tags": ["可信数据空间", "数字合约", "征求意见稿"],
        "impacts": ["可信数据空间", "数字合约", "数据流通与使用控制", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施+可信空间202508/5.技术文件-《可信数据空间 使用控制技术要求（征求意见稿）》.pdf",
        "wiki_file": "TC609-202508-可信数据空间使用控制技术要求-征求意见稿.md",
        "title": "可信数据空间 使用控制技术要求（征求意见稿）",
        "doc_type": "draft",
        "status_label": "征求意见稿（TC609）",
        "org": "全国数据标准化技术委员会（以 PDF 为准）",
        "version_date": "2025-08",
        "one_liner_fb": "可信数据空间使用控制技术要求征求意见稿。",
        "tags": ["可信数据空间", "使用控制", "征求意见稿"],
        "impacts": ["可信数据空间", "使用控制", "数据流通与使用控制", "可信数据空间政策与标准清单"],
    },
    {
        "raw": "Raw/政策/数据基础设施+可信空间202508/6.技术文件-《可信数据空间 技术能力评价规范（征求意见稿）》.pdf",
        "wiki_file": "TC609-202508-可信数据空间技术能力评价规范-征求意见稿.md",
        "title": "可信数据空间 技术能力评价规范（征求意见稿）",
        "doc_type": "draft",
        "status_label": "征求意见稿（TC609）",
        "org": "全国数据标准化技术委员会（以 PDF 为准）",
        "version_date": "2025-08",
        "one_liner_fb": "可信数据空间技术能力评价规范征求意见稿。",
        "tags": ["可信数据空间", "能力评价", "征求意见稿"],
        "impacts": ["可信数据空间", "可信数据空间政策与标准清单"],
    },
]


def main() -> None:
    import sys

    OUT.mkdir(parents=True, exist_ok=True)
    specs = SPECS
    if "--ndi-only" in sys.argv:
        specs = [s for s in SPECS if s["wiki_file"].startswith("NDI-TR")]
    for spec in specs:
        path = WIKI_ROOT / spec["raw"]
        text, pages = extract_pdf(path)
        note = build_note(
            rel_raw=spec["raw"],
            title=spec["title"],
            doc_type=spec["doc_type"],
            status_label=spec["status_label"],
            org=spec["org"],
            version_date=spec["version_date"],
            fallback_one_liner=spec["one_liner_fb"],
            tags=spec["tags"],
            impacts=spec["impacts"],
            text=text,
            pages=pages,
            extraction_note=spec.get("extraction_note"),
        )
        out_path = OUT / spec["wiki_file"]
        out_path.write_text(note, encoding="utf-8")
        print("wrote", out_path.relative_to(WIKI_ROOT), "chars", len(text))


if __name__ == "__main__":
    main()
