# 新型主体领域知识图谱

**位置**：`memory/ontology/`
**作用**：图谱导航层 → 定位目标报告 → 读报告取详情
**нцип**："图谱找报告，报告取详情"；图谱轻量简洁，详情全在报告里

---

## 实体类型

| 类型 | 说明 |
|------|------|
| `Province` | 省份节点（图谱入口） |
| `ProvinceVPP` | 某省某种新型主体的规则实体 |
| `ReportFile` | 已入库的报告文件 |

## 关系类型

| 关系 | 说明 |
|------|------|
| `has_vpp_entity` | 省份 → VPP实体 |
| `report_located_at` | VPP实体 → 报告文件（一对一） |
| `same_subject` | 同类主体跨省关系（对称，用于横向对比） |

---

## 查询示例

```bash
# 1. 某省某主体 → 直接找到报告文件
python3 scripts/ontology.py related --id vppsd --rel report_located_at

# 2. 某类主体有哪些省 → 跨省对比
python3 scripts/ontology.py query --type ProvinceVPP --where '{"subject":"虚拟电厂"}'

# 3. 某省有哪些主体
python3 scripts/ontology.py related --id province_sd --rel has_vpp_entity

# 4. 找所有confirmed（已核实）主体
python3 scripts/ontology.py query --type ProvinceVPP --where '{"status":"confirmed"}'
```

---

## 图谱层 vs 报告层 分工

| 层次 | 工具 | 存什么 | 回答什么 |
|------|------|--------|---------|
| **图谱层**（这里） | graph.jsonl | 实体摘要+关系 | "山东有哪些VPP主体？哪些省有储能类VPP？" |
| **报告层**（memory/reports/） | .md文件 | 完整规则原文 | "山东储能类VPP节点电价具体多少？怎么参与辅助服务？" |

**原则**：图谱不写详细参数（避免重复维护），只存定位信息和核心摘要，详细一律读报告。

---

## 新增省份入库

1. 在 graph.jsonl 末尾追加 Province 节点
2. 追加 ProvinceVPP 实体（核心摘要，不超过10个字段）
3. 追加 ReportFile 实体
4. 追加3条关系（has_vpp_entity × 2 + report_located_at）
5. 如有同类主体跨省，追加 same_subject 关系

---

*最后更新：2026-03-27*
